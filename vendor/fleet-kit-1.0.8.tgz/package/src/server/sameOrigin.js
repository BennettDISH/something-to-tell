// Writes must come from the app's own pages.
//
// The session cookie is SameSite=Lax, which keeps it off requests other sites send. But a "site"
// is the whole registrable domain: behind a shared front door every app is a sibling under one
// domain, so a page on any of them is the same site, and a plain form it posts here would carry
// the player's cookie. Browsers say where a request came from in Sec-Fetch-Site; anything that
// changes something is let through only from this origin.
//
// A request without the header passes: a browser from before 2023 still keeps the cookie off
// other sites, and a script (curl, the tests) holds no one's cookie. Reads pass too: another page
// cannot read the answer without CORS, which is off.

const READS = new Set(['GET', 'HEAD', 'OPTIONS']);

/** Mount on '/api'. `except` lists paths (under the mount) made for other sites: a lead form,
 *  a widget's intake. */
export function sameOriginWrites({ message = 'This request has to come from the site itself.', except = [] } = {}) {
  return (req, res, next) => {
    if (READS.has(req.method)) return next();
    if (except.some((p) => req.path === p || req.path.startsWith(`${p.replace(/\/$/, '')}/`))) return next();
    const from = req.get('sec-fetch-site');
    if (from && from !== 'same-origin') return res.status(403).json({ error: message });
    next();
  };
}

const LOCAL_HOSTS = new Set(['localhost', '127.0.0.1', '[::1]']);

/**
 * The Origin check for what a cookie alone would sign in and Sec-Fetch-Site does not cover: the
 * WebSocket upgrade. Browsers send Origin on every WebSocket handshake and every cross-site POST,
 * so a present Origin that is not ours is another site driving the player's browser. Ours is the
 * host the request was sent to (Host, or X-Forwarded-Host from a proxy; a page elsewhere cannot
 * set either), `baseUrl` (APP_BASE_URL) when set, and any localhost outside production. No Origin
 * at all is a non-browser client, which holds no player's cookie.
 */
export function originAllowed(req, { baseUrl = process.env.APP_BASE_URL, env = process.env } = {}) {
  const origin = req.headers?.origin;
  if (origin === undefined) return true;
  let url;
  try {
    url = new URL(origin);
  } catch {
    return false; // "null" (sandboxed frames, files) and junk
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return false;
  const sentTo = [req.headers.host, ...String(req.headers['x-forwarded-host'] ?? '').split(',')]
    .map((h) => String(h ?? '').trim().toLowerCase())
    .filter(Boolean);
  if (sentTo.includes(url.host)) return true;
  if (baseUrl) {
    try {
      if (new URL(baseUrl).origin === url.origin) return true;
    } catch {
      /* a malformed base matches nothing */
    }
  }
  return env.NODE_ENV !== 'production' && LOCAL_HOSTS.has(url.hostname);
}
