// The end of every app's middleware: a JSON 404 for an /api path nobody answered (not the app's
// HTML page with a 200, which the client takes for an empty success), a plain 404 for a missing
// build asset (a tab older than the last deploy), the page fallback, and the last handler. A 4xx
// says what was wrong; a 5xx is logged with the request id and the visitor gets a plain
// sentence, never the error itself (a database's words name tables, columns, hosts).
import fs from 'node:fs';
import { STATUS_CODES } from 'node:http';
import { logError } from './log.js';

/** An error a route throws to answer with: `throw new HttpError(404, 'No such game')`. */
export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
    this.expose = status < 500;
  }
}
export const httpError = (status, message) => new HttpError(status, message);

/** An async middleware with its rejection passed to next(err). Express 4 does not look at what a
 *  handler returns, so a rejection there is unhandled, and Node exits on those. The promise is
 *  still returned, for a hand call to wait on; a hand call's own `next` is the one given the error. */
export const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/** Postgres errors a bad request causes, answered as 4xx in plain words. */
export const PG_CLIENT_ERRORS = {
  '22P02': [400, 'Invalid id or value'],
  '22001': [400, 'A value is too long'],
  '22003': [400, 'A number is out of range'],
  '22007': [400, 'Invalid date or time'],
  '22008': [400, 'Invalid date or time'],
  '23502': [400, 'A required value is missing'],
  '23503': [400, 'That item does not exist'],
  '23505': [409, 'That already exists'],
  '23514': [400, 'Invalid value'],
};

/** app.use('/api', apiNotFound()) after every API router. */
export const apiNotFound = (message = 'No such endpoint') => (_req, res) => res.status(404).json({ error: message });

/** app.use('/assets', assetNotFound()) after the static files. */
export const assetNotFound = () => (_req, res) => res.status(404).end();

/** The single-page app's fallback for GET and HEAD: index.html, never kept by the browser (a
 *  tab coming back would show the page from before a deploy). Mount with app.use() last before
 *  the error handler; it works the same under Express 4 and 5. `skip` leaves /api and /assets
 *  to their 404s. */
export function spaFallback(file, { skip = /^\/(?:api|assets)(?:\/|$)/ } = {}) {
  return (req, res, next) => {
    if ((req.method !== 'GET' && req.method !== 'HEAD') || skip.test(req.path)) return next();
    if (!fs.existsSync(file)) return next();
    res.sendFile(file, { cacheControl: false, headers: { 'Cache-Control': 'no-store' } });
  };
}

/**
 * The last handler. Body parser refusals get a plain sentence (413 too large, 400 not JSON); an
 * upload refused by multer is a 400; an HttpError (or any error with expose and a 4xx status)
 * says its own message, and a 4xx marked expose: false (res.sendFile's missing file is a 404 whose
 * words name a path) keeps its status with the standard phrase; `pg` maps Postgres' bad-request
 * codes; `messages` overrides the words ({ tooLarge, badJson, server }). Everything else is
 * logged and answered 500.
 */
export function errorHandler({ pg = true, messages = {} } = {}) {
  const say = {
    tooLarge: 'That is too large to send.',
    badJson: 'That request was not valid JSON.',
    upload: "That upload didn't work.",
    uploadTooLarge: 'That file is too large.',
    server: 'Something went wrong',
    ...messages,
  };
  // eslint-disable-next-line no-unused-vars
  return (err, req, res, next) => {
    if (res.headersSent) return next(err);
    if (err?.type === 'entity.too.large') return res.status(413).json({ error: say.tooLarge });
    if (err?.type === 'entity.parse.failed' || (err instanceof SyntaxError && 'body' in err)) return res.status(400).json({ error: say.badJson });
    if (err?.name === 'MulterError') return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? say.uploadTooLarge : say.upload });
    const status = Number(err?.status ?? err?.statusCode);
    if (Number.isInteger(status) && status >= 400 && status < 500) {
      const words = err.expose === false ? STATUS_CODES[status] : err.message;
      return res.status(status).json({ error: words || 'Bad request' });
    }
    const known = pg ? PG_CLIENT_ERRORS[err?.code] : null;
    if (known) return res.status(known[0]).json({ error: known[1] });
    logError(req, err);
    res.status(500).json({ error: say.server });
  };
}
