// Migrations. A failed step throws, and the app's boot stops on it (it never serves on a schema
// half made); there is no down, only a new forward step.
//
// Postgres: files in `dir` named NNN_snake_case.sql are applied once each, in numeric order, each
// in its own transaction, and recorded in schema_migrations. Never edit or renumber a file that
// has shipped: it is recorded as applied and will not run again. An advisory lock makes two
// instances booting together (an old and a new deploy) take turns.
//
// SQLite (node:sqlite): a list of steps, SQL or a function when a step moves data, counted by
// PRAGMA user_version. A new feature adds an entry at the end.
import fs from 'node:fs/promises';
import path from 'node:path';

const NAME = /^(\d{3})_[a-z0-9_]+\.sql$/;
export const DEFAULT_LOCK = 7310411;

/** The migration files, sorted; two sharing a number is an error. */
export async function listMigrations(dir) {
  const files = (await fs.readdir(dir)).filter((f) => NAME.test(f)).sort();
  const seen = new Map();
  for (const f of files) {
    const n = f.slice(0, 3);
    if (seen.has(n)) throw new Error(`two migrations share number ${n}: ${seen.get(n)} and ${f}`);
    seen.set(n, f);
  }
  return files;
}

/** One transaction on one connection: a pg Pool's (connect/release), or the client itself. */
async function inTransaction(db, fn) {
  const client = typeof db.connect === 'function' ? await db.connect() : db;
  try {
    await client.query('BEGIN');
    try {
      const out = await fn(client);
      await client.query('COMMIT');
      return out;
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      throw err;
    }
  } finally {
    if (client !== db) client.release?.();
  }
}

/** Applies what is pending in `dir` and returns the names applied this time. Throws on the
 *  first failure, leaving that migration and everything after it unapplied. `db` is a pg Pool
 *  (or one client); `lockKey` should differ between apps sharing a database. */
export async function migrate({ db, dir, lockKey = DEFAULT_LOCK, table = 'schema_migrations' }) {
  if (!/^[a-z_][a-z0-9_]*$/.test(table)) throw new Error(`bad migrations table name ${table}`);
  const files = await listMigrations(dir);
  await inTransaction(db, async (c) => {
    await c.query('SELECT pg_advisory_xact_lock($1)', [lockKey]);
    await c.query(`CREATE TABLE IF NOT EXISTS ${table} (name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())`);
  });
  const applied = [];
  for (const name of files) {
    const sql = await fs.readFile(path.join(dir, name), 'utf8');
    await inTransaction(db, async (c) => {
      await c.query('SELECT pg_advisory_xact_lock($1)', [lockKey]);
      const { rows } = await c.query(`SELECT 1 FROM ${table} WHERE name = $1`, [name]);
      if (rows.length) return;
      try {
        await c.query(sql); // no parameters: the simple protocol runs several statements
      } catch (err) {
        throw new Error(`migration ${name} failed: ${err.message}`);
      }
      await c.query(`INSERT INTO ${table} (name) VALUES ($1)`, [name]);
      applied.push(name);
    });
  }
  return applied;
}

/** Runs the SQLite steps not yet counted in PRAGMA user_version, each in its own transaction.
 *  Foreign keys are off while it runs (SQLite only switches them outside a transaction, and a
 *  table rebuild needs them off), so each step checks every reference before it commits.
 *  Returns how many steps ran. */
export function migrateSqlite(db, steps) {
  const done = db.prepare('PRAGMA user_version').get().user_version;
  let ran = 0;
  db.exec('PRAGMA foreign_keys = OFF');
  try {
    for (let v = done; v < steps.length; v++) {
      db.exec('BEGIN IMMEDIATE');
      try {
        const step = steps[v];
        if (typeof step === 'function') step(db);
        else db.exec(step);
        const broken = db.prepare('PRAGMA foreign_key_check').all();
        if (broken.length) throw new Error(`Migration ${v + 1} would leave ${broken.length} broken references`);
        db.exec(`PRAGMA user_version = ${v + 1}`);
        db.exec('COMMIT');
        ran++;
      } catch (err) {
        db.exec('ROLLBACK');
        throw err;
      }
    }
  } finally {
    db.exec('PRAGMA foreign_keys = ON');
  }
  return ran;
}
