// Security headers on every response, without helmet: an enforced Content-Security-Policy, HSTS,
// frame protection, no MIME sniffing, a Referrer-Policy, a cross-origin opener policy, and no
// X-Powered-By banner.
//
// The CSP starts strict (everything from this origin only, no inline script, no framing) and
// adds what the fleet's pages really load: the bug widget's origin in script-src and connect-src
// (it also draws its shadow-root style inline, hence 'unsafe-inline' in style-src, and resizes a
// screenshot through blob:), and Waypoint's origin in form-action (a form that posts to the
// app's own sign-in route is redirected there). A new CSP is checked in a browser before it
// ships: the pages, the widget, sign-in, images, maps and sockets.
import crypto from 'node:crypto';

/** Where a per-response nonce goes in a policy: buildCsp's `nonce` puts it in script-src. */
export const NONCE = "'nonce-{nonce}'";

const DEFAULTS = {
  'default-src': ["'self'"],
  'script-src': ["'self'"],
  'style-src': ["'self'", "'unsafe-inline'"],
  'img-src': ["'self'", 'data:', 'blob:'],
  'font-src': ["'self'"],
  'connect-src': ["'self'"],
  'object-src': ["'none'"],
  'base-uri': ["'none'"],
  'form-action': ["'self'"],
  'frame-ancestors': ["'none'"],
};

const originOf = (url) => {
  try {
    return url ? new URL(url).origin : null;
  } catch {
    return null;
  }
};

/**
 * The policy as a header value. `widgetOrigin` and `authOrigin` are added where they belong;
 * `add` appends sources per directive ({ 'img-src': ['https://tile.example.org'] }); `replace`
 * sets a directive outright, and null drops it. `nonce` true adds NONCE to script-src, for
 * securityHeaders({ csp: <this>, nonce: true }) to fill in per response.
 */
export function buildCsp({ widgetOrigin, authOrigin = originOf(process.env.AUTH_SERVICE_URL), add = {}, replace = {}, nonce = false } = {}) {
  const d = Object.fromEntries(Object.entries(DEFAULTS).map(([k, v]) => [k, [...v]]));
  if (nonce) d['script-src'].push(NONCE);
  const widget = originOf(widgetOrigin);
  if (widget) d['script-src'].push(widget), d['connect-src'].push(widget);
  const auth = originOf(authOrigin);
  if (auth) d['form-action'].push(auth);
  for (const [k, v] of Object.entries(add)) d[k] = [...new Set([...(d[k] || []), ...v])];
  for (const [k, v] of Object.entries(replace)) {
    if (v === null) delete d[k];
    else d[k] = [...v];
  }
  return Object.entries(d).map(([k, v]) => (v.length ? `${k} ${v.join(' ')}` : k)).join('; ');
}

/**
 * Middleware. `frameAncestors` is the CSP's frame-ancestors ("'none'" by default; "'self'" for an
 * app that frames its own pages), and X-Frame-Options follows it for older browsers. HSTS goes
 * out over https only (req.secure: behind the platform's proxy that needs trust proxy 1), as the
 * standard says; `hsts` false leaves it off (a proxy that sets its own). `csp` false sends no CSP
 * (a page that is someone else's, proxied); a string is a policy made with buildCsp. `coop` null
 * leaves Cross-Origin-Opener-Policy off.
 *
 * `nonce` true: every response gets a fresh nonce in res.locals.cspNonce and in script-src, for a
 * page's own inline scripts (<script nonce="…">). A `csp` string then needs NONCE where it goes
 * (buildCsp({ nonce: true }) puts it there).
 */
export function securityHeaders({
  widgetOrigin,
  authOrigin,
  add,
  replace,
  frameAncestors = "'none'",
  csp = true,
  hsts = true,
  referrerPolicy = 'strict-origin-when-cross-origin',
  coop = 'same-origin',
  nonce = false,
} = {}) {
  const policy = typeof csp === 'string' ? csp : csp
    ? buildCsp({ widgetOrigin, ...(authOrigin !== undefined ? { authOrigin } : {}), add, replace: { 'frame-ancestors': [frameAncestors], ...replace }, nonce })
    : null;
  if (nonce && !policy?.includes(NONCE)) throw new Error(`securityHeaders: nonce needs a CSP with ${NONCE} in it (buildCsp({ nonce: true }))`);
  const xfo = frameAncestors === "'none'" ? 'DENY' : frameAncestors === "'self'" ? 'SAMEORIGIN' : null;
  return (req, res, next) => {
    res.removeHeader('X-Powered-By');
    if (nonce) {
      const value = crypto.randomBytes(16).toString('base64');
      res.locals.cspNonce = value;
      res.setHeader('Content-Security-Policy', policy.replaceAll(NONCE, `'nonce-${value}'`));
    } else if (policy) res.setHeader('Content-Security-Policy', policy);
    if (xfo) res.setHeader('X-Frame-Options', xfo);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', referrerPolicy);
    // the platform's names are HSTS-preloaded through their TLD; a custom domain is not. No
    // includeSubDomains by default: on someone else's apex it would bind all their subdomains.
    if (hsts && req.secure) res.setHeader('Strict-Transport-Security', typeof hsts === 'string' ? hsts : 'max-age=31536000');
    if (coop) res.setHeader('Cross-Origin-Opener-Policy', coop);
    next();
  };
}

/** app.use('/api', noStore()) for an app that decides who's signed in its own way, or that loads
 *  the user and checks req.user itself: the browser keeps none of it. A public answer that should
 *  be cached says so itself with res.set, after this. requireUser and requireAdmin already do it. */
export const noStore = () => (_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
};
