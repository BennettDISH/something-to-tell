// Guests nobody has seen for a while go, with the rows that are only theirs.
//
// One engine fed the app's own tables: `users` names the accounts table (its central id, how it
// knows a guest, when it last saw one), `owned` the tables holding a guest's own rows (each by the
// column naming the guest), deleted in that order before the account row.
//
// Its holds (Spellforge's services/guests.js, Tilerealm's guestSweep.js):
//   1. Waypoint's word first (guestCheck.js): only an unclaimed guest, or an id no Waypoint
//      account has any more, may go. A claimed one stays and stops being a guest here; one
//      Waypoint does not link to this app stays and is logged. If Waypoint cannot answer, nobody
//      goes that run.
//   2. Each piece runs on one snapshot (REPEATABLE READ): the question, the delete and the counts
//      see the same moment.
//   3. The piece is measured: every row not belonging to the guests going is counted before the
//      delete and after it, in every table named here and any `census` the app adds, and the
//      piece is undone if a count moved (a cascade the app did not name, say). Whatever the
//      question missed is kept, and logged.
//   4. A piece the database will not let go (a key that refuses, a row changed under it, a
//      deadlock) is tried one guest at a time; the one that cannot go waits for the next run.
//   5. Never sooner than a session lasts (`sessionDays`): a guest whose cookie still works is
//      still in use.
// It runs a minute after boot and then daily; GUEST_CLEANUP_ENABLED=false turns it off and
// GUEST_RETENTION_DAYS (30) sets the window. A failure is logged, never thrown.
import { checkGuests } from './guestCheck.js';

const DAY_MS = 24 * 60 * 60 * 1000;
const IDENT = /^[a-z_][a-z0-9_]*$/;
const ident = (name) => {
  if (!IDENT.test(name)) throw new Error(`guest sweep: "${name}" is not a plain table or column name`);
  return name;
};

/** The two env switches. */
export function guestSweepSettings(env = process.env) {
  const days = Number(env.GUEST_RETENTION_DAYS || 30);
  return { days, enabled: env.GUEST_CLEANUP_ENABLED !== 'false' };
}

const cannotGo = (err) => /^(23|40|P0)/.test(err?.code ?? '');
const pieces = (list, n) => Array.from({ length: Math.ceil(list.length / n) }, (_, i) => list.slice(i * n, i * n + n));

export async function sweepGuests({
  db,
  check = (ids) => checkGuests(ids),
  users,
  owned = [],
  census = [],
  keep,
  days = guestSweepSettings().days,
  sessionDays = 30,
  lockKey = 4734110,
  batch = 250,
  dryRun = false,
}) {
  if (!Number.isFinite(days) || days < 1) throw new Error(`GUEST_RETENTION_DAYS must be a positive number, got ${days}`);
  const T = ident(users.table);
  const ID = ident(users.id ?? 'central_user_id');
  const SEEN = ident(users.seen ?? 'last_seen_at');
  const guestColumn = typeof users.guest === 'string' || users.guest === undefined ? ident(users.guest ?? 'is_guest') : null;
  const isGuest = guestColumn ? `u.${guestColumn}` : `(${users.guest.sql})`;
  const tables = owned.map((o) => ({ table: ident(o.table), column: ident(o.column ?? 'central_user_id') }));
  const window = String(Math.max(days, sessionDays));
  const idleSql = `${isGuest} AND COALESCE(u.${SEEN}, NOW()) < NOW() - ($1 || ' days')::interval${keep ? ` AND NOT (${keep})` : ''}`;
  const counts = [
    ...tables.map(({ table, column }) => [`${table} kept`, `SELECT count(*) FROM ${table} WHERE NOT (${column}::text = ANY($1::text[]))`]),
    [`${T} kept`, `SELECT count(*) FROM ${T} WHERE NOT (${ID}::text = ANY($1::text[]))`],
    ...census,
  ];
  const COUNT = `SELECT ${counts.map(([, sql], i) => `(${sql})::text AS c${i}`).join(', ')}`;

  const client = await db.connect();
  try {
    if (!(await client.query('SELECT pg_try_advisory_lock($1) AS ok', [lockKey])).rows[0].ok) return { skipped: 'another sweep is running' };
    try {
      const { rows } = await client.query(`SELECT u.${ID}::text AS id FROM ${T} u WHERE ${idleSql} ORDER BY u.${SEEN}`, [window]);
      const idle = rows.map((r) => r.id);
      if (!idle.length) return { stale: 0, removed: 0, kept: 0 };
      const verdict = await check(idle);
      if (!verdict.ok) return { stale: idle.length, removed: 0, kept: idle.length, held: verdict.reason };
      if (verdict.unknown.length) console.error(`Guest sweep: ${verdict.unknown.length} idle guest(s) left in place, Waypoint does not link them to this app: ${verdict.unknown.slice(0, 20).join(', ')}`);
      if (verdict.claimed.length && guestColumn && !dryRun) {
        await client.query(`UPDATE ${T} SET ${guestColumn} = false WHERE ${ID}::text = ANY($1::text[])`, [verdict.claimed]);
      }
      const noted = { ...(verdict.claimed.length ? { claimed: verdict.claimed.length } : {}), ...(verdict.unknown.length ? { unknown: verdict.unknown.length } : {}) };
      if (dryRun) return { stale: idle.length, removed: 0, kept: idle.length, wouldRemove: verdict.clear.length, ...noted };

      /** One piece, all of it or none: { went } or { moved } or { refused }. */
      async function piece(ids) {
        await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ');
        try {
          const { rows: still } = await client.query(
            `SELECT u.${ID}::text AS id FROM ${T} u WHERE u.${ID}::text = ANY($2::text[]) AND ${idleSql}`, [window, ids]);
          const going = still.map((r) => r.id);
          if (!going.length) {
            await client.query('ROLLBACK');
            return { went: [] };
          }
          const before = (await client.query(COUNT, [going])).rows[0];
          for (const { table, column } of tables) await client.query(`DELETE FROM ${table} WHERE ${column}::text = ANY($1::text[])`, [going]);
          await client.query(`DELETE FROM ${T} WHERE ${ID}::text = ANY($1::text[])`, [going]);
          const after = (await client.query(COUNT, [going])).rows[0];
          const moved = counts.map(([what], i) => (before[`c${i}`] === after[`c${i}`] ? null : `${what} ${before[`c${i}`]} → ${after[`c${i}`]}`)).filter(Boolean);
          if (moved.length) {
            await client.query('ROLLBACK');
            return { moved };
          }
          await client.query('COMMIT');
          return { went: going };
        } catch (err) {
          await client.query('ROLLBACK').catch(() => {});
          if (!cannotGo(err)) throw err;
          return { refused: `${err.code} ${String(err.message).split('\n')[0]}` };
        }
      }

      let removed = 0;
      for (const ids of pieces(verdict.clear, batch)) {
        const whole = await piece(ids);
        if (whole.went) {
          removed += whole.went.length;
          continue;
        }
        for (const id of ids) {
          const one = await piece([id]);
          if (one.went) {
            removed += one.went.length;
            continue;
          }
          console.error(one.moved
            ? `Guest sweep: guest ${id} left in place — taking it would change what must stay: ${one.moved.join(', ')}`
            : `Guest sweep: guest ${id} left for the next run — the database would not let it go: ${one.refused}`);
        }
      }
      return { stale: idle.length, removed, kept: idle.length - removed, ...noted };
    } finally {
      await client.query('SELECT pg_advisory_unlock($1)', [lockKey]).catch(() => {});
    }
  } finally {
    client.release?.();
  }
}

/** One run, as the timer makes it: what happened is logged, and a failure too, never thrown.
 *  `sweep` is the app's own sweep (or () => sweepGuests({...})). */
export async function runGuestSweep(sweep) {
  try {
    const r = await sweep();
    if (r?.held) console.error(`Guest sweep paused, nobody removed (${r.stale} idle guest(s) waiting): ${r.held}. It runs again tomorrow.`);
    else if (r?.removed || r?.kept) console.log(`Guest sweep: ${r.removed} idle guest(s) removed; ${r.kept} left in place`);
    return r;
  } catch (err) {
    console.error('Guest sweep failed (it runs again tomorrow):', err?.message ?? err);
    return { failed: err?.message ?? String(err) };
  }
}

/** A minute after boot, then daily, unless GUEST_CLEANUP_ENABLED=false or `off` says why not.
 *  The timers never keep the process up. Returns a stop function. */
export function scheduleGuestSweep(sweep, { env = process.env, off, delayMs = 60_000, everyMs = DAY_MS } = {}) {
  const why = env.GUEST_CLEANUP_ENABLED === 'false' ? 'GUEST_CLEANUP_ENABLED=false' : off || null;
  if (why) {
    console.log(`Guest sweep off (${why})`);
    return () => {};
  }
  const first = setTimeout(() => runGuestSweep(sweep), delayMs);
  const daily = setInterval(() => runGuestSweep(sweep), everyMs);
  first.unref?.();
  daily.unref?.();
  return () => {
    clearTimeout(first);
    clearInterval(daily);
  };
}
