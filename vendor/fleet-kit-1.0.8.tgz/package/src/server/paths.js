// One reading of a request path for every gate.
//
// Express routes ignore case and a trailing slash, and a mount takes /api/auth//register as
// /register; express.static decodes %xx, collapses // and resolves /x/../; a browser's router
// decodes, and a browser reads a backslash as a slash. A gate that reads req.path once can be
// walked past by any of those, so it asks about all of them. Asked this way it can only fire more
// often than the page would be served, never less.

// A bad escape stays as it was sent; the rest of the path is still decoded.
const decodeOnce = (path) =>
  path.replace(/(?:%[0-9a-f]{2})+/gi, (run) => {
    try {
      return decodeURIComponent(run);
    } catch {
      return run;
    }
  });

function tidyPath(path) {
  const parts = [];
  for (const part of path.replace(/\\/g, '/').split('/')) {
    if (part === '..') parts.pop();
    else if (part && part !== '.') parts.push(part);
  }
  return `/${parts.join('/')}`;
}

/**
 * Every way a request path can name a page: the path as sent and each decoding of it (three at
 * most: nothing downstream goes further), each also tidied, with and without a trailing slash.
 */
export function pathSpellings(path) {
  const seen = new Set();
  let spelled = String(path);
  for (let decodings = 0; decodings <= 3; decodings += 1) {
    const tidy = tidyPath(spelled);
    seen.add(spelled).add(tidy).add(`${tidy}/`);
    const decoded = decodeOnce(spelled);
    if (decoded === spelled) break;
    spelled = decoded;
  }
  return [...seen];
}

/**
 * A test of one path against a pattern (a RegExp, or anything with test(path)), in any case and
 * every spelling: `const isAdminPath = pathMatcher(/^\/admin(?:\/|$)/)`, then
 * `isAdminPath(req.path)` in a gate. A global or sticky RegExp would remember where it stopped
 * between requests, so those flags go.
 */
export function pathMatcher(pattern) {
  if (typeof pattern?.test !== 'function') throw new Error('pathMatcher needs a RegExp, or something with test(path)');
  let one;
  if (pattern instanceof RegExp) {
    const anyCase = new RegExp(pattern.source, [...new Set(`${pattern.flags}i`.replace(/[gy]/g, ''))].join(''));
    one = (path) => anyCase.test(path);
  } else {
    one = (path) => pattern.test(path) || pattern.test(path.toLowerCase());
  }
  return (path) => pathSpellings(path).some(one);
}
