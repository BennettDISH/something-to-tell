// <fleet-topbar>: the bar every game shares, as a web component, so React, plain JS and
// TypeScript games load the same file. One fixed 40px strip (plus the notch on phones that draw
// under it: the viewport meta says viewport-fit=cover), "◂ All games" on the left and the
// account chip on the right (Sign in; or Switch account, Sign out, Sign out of all games).
//
//   <link rel="stylesheet" href="…/topbar.css">  (optional: the page keeps its band from the start)
//   <script type="module" src="…/topbar.js"></script>
//   <fleet-topbar home="https://games.example.com/"></fleet-topbar>
//
// Attributes: home (the hub's address; no home, no link), home-label ("All games"), auth (the
// app's sign-in routes, /api/auth), accounts="off" (a game without accounts: no chip), manual (the
// app sets .account itself instead of the bar asking auth/me), sso="off" (with manual: no Waypoint,
// so no Switch account or Sign out of all games), no-pad (the page lays itself out under the
// bar; otherwise the body gets padding-top: var(--fleet-topbar-height)).
//
// It asks `${auth}/me` (the session cookie rides along) and shows "Guest" for a guest. The menu's
// actions are events the app may take over (preventDefault): fleet-topbar-signin, -switch,
// -signout, -signout-all. Left alone they do the usual: Waypoint's sign-in coming back here;
// the same asking who you are; POST `${auth}/logout` then reload; that, then Waypoint's own
// sign-out, which comes back to home. The bar's keys (Enter, Esc, arrows) stay out of the game.

const CSS = `
:host { position: fixed; top: 0; left: 0; right: 0; z-index: var(--fleet-topbar-z, 1000); display: block;
  height: var(--fleet-topbar-height, calc(40px + env(safe-area-inset-top, 0px))); box-sizing: border-box;
  padding: env(safe-area-inset-top, 0px) max(16px, env(safe-area-inset-right, 0px)) 0 max(16px, env(safe-area-inset-left, 0px));
  background: rgba(17, 24, 39, 0.92); color: #f9fafb;
  font: 400 14px/1.2 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; letter-spacing: normal; text-align: left; }
:host([hidden]) { display: none; }
*, *::before, *::after { box-sizing: border-box; }
nav { height: 100%; display: flex; align-items: center; justify-content: space-between; gap: 12px; }
a, button { -webkit-tap-highlight-color: transparent; }
.home { flex-shrink: 0; margin-left: -8px; padding: 6px 8px; border-radius: 6px; color: #f9fafb; text-decoration: none; white-space: nowrap; }
.home:hover { background: rgba(255, 255, 255, 0.1); }
a:focus-visible, button:focus-visible { outline: 2px solid #93c5fd; outline-offset: 2px; }
.acct { position: relative; min-width: 0; display: flex; margin-left: auto; }
.chip { display: inline-flex; align-items: center; gap: 6px; min-width: 0; max-width: min(55vw, 260px); height: 28px; margin: 0;
  padding: 0 10px; border: 1px solid rgba(249, 250, 251, 0.4); border-radius: 999px; background: transparent; color: #f9fafb;
  font: inherit; line-height: 1; cursor: pointer; }
.chip:hover, .chip[aria-expanded='true'] { background: rgba(255, 255, 255, 0.1); }
.name { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.caret { flex: none; font-size: 11px; }
.menu { position: absolute; top: calc(100% + 6px); right: 0; min-width: 210px; max-width: calc(100vw - 32px); margin: 0; padding: 4px;
  background: #1f2937; border: 1px solid #374151; border-radius: 8px; box-shadow: 0 8px 24px rgba(0, 0, 0, 0.45); }
.menu button { display: block; width: 100%; margin: 0; padding: 9px 12px; border: 0; border-radius: 6px; background: transparent;
  color: #f9fafb; font: inherit; text-align: left; white-space: nowrap; cursor: pointer; }
.menu button:hover, .menu button:focus-visible { background: #374151; outline: none; }
`;

// the page's part: the height every game lays itself out by, and the body's band under the bar
const PAGE_CSS = `
:root { --fleet-topbar-height: calc(40px + env(safe-area-inset-top, 0px)); }
html.fleet-topbar-pad body { padding-top: var(--fleet-topbar-height); }
`;

const sheet = (text) => {
  try {
    const s = new CSSStyleSheet();
    s.replaceSync(text);
    return s;
  } catch {
    return null; // a browser without constructable sheets gets a <style> instead
  }
};

let pageStyled = false;
function stylePage() {
  if (pageStyled) return;
  pageStyled = true;
  const s = sheet(PAGE_CSS);
  if (s && 'adoptedStyleSheets' in document) document.adoptedStyleSheets = [...document.adoptedStyleSheets, s];
  else {
    const el = document.createElement('style');
    el.textContent = PAGE_CSS;
    document.head.append(el);
  }
}

const make = (tag, attrs = {}, text) => {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  if (text != null) el.textContent = text;
  return el;
};

const ITEMS = [
  ['switch', 'Switch account'],
  ['signout', 'Sign out'],
  ['signout-all', 'Sign out of all games'],
];

/** What a /me answer's user is called on the chip: "Guest" for a guest. */
export function chipLabel(user) {
  if (!user) return null;
  if (user.is_guest || user.isGuest || user.guest) return 'Guest';
  return String(user.username ?? user.name ?? 'Account');
}

// (a server-side import, or a test in Node, gets the helpers without a DOM)
const Base = typeof HTMLElement === 'undefined' ? class {} : HTMLElement;

export class FleetTopbar extends Base {
  static observedAttributes = ['home', 'home-label', 'accounts', 'no-pad', 'sso'];

  #root;
  #home;
  #acct;
  #chip = null;
  #menu = null;
  #open = false;
  #account; // undefined: still asking (or no accounts); null: signed out; { name, guest }
  #ssoEnabled = true;
  #away = (e) => {
    if (!e.composedPath().includes(this.#acct)) this.#close();
  };

  constructor() {
    super();
    this.#root = this.attachShadow({ mode: 'open' });
    const s = sheet(CSS);
    if (s && 'adoptedStyleSheets' in this.#root) this.#root.adoptedStyleSheets = [s];
    else this.#root.append(make('style', {}, CSS));
    const nav = make('nav', { 'aria-label': 'Games and account' });
    this.#home = make('a', { class: 'home', part: 'home' });
    this.#acct = make('div', { class: 'acct' });
    nav.append(this.#home, this.#acct);
    this.#root.append(nav);
    // the game's own keys (Enter to chat, Esc for the menu, WASD) stay out of the bar
    this.addEventListener('keydown', (e) => e.stopPropagation());
    this.#acct.addEventListener('keydown', (e) => this.#onKey(e));
  }

  get auth() {
    return (this.getAttribute('auth') || '/api/auth').replace(/\/+$/, '');
  }

  connectedCallback() {
    stylePage();
    this.#syncPad();
    this.#renderHome();
    if (this.getAttribute('accounts') !== 'off' && !this.hasAttribute('manual')) this.refresh();
  }

  disconnectedCallback() {
    this.#close();
    document.documentElement.classList.remove('fleet-topbar-pad');
  }

  attributeChangedCallback() {
    if (!this.isConnected) return;
    this.#syncPad();
    this.#renderHome();
    if (this.getAttribute('accounts') === 'off') this.account = undefined;
  }

  #syncPad() {
    document.documentElement.classList.toggle('fleet-topbar-pad', !this.hasAttribute('no-pad'));
  }

  #renderHome() {
    const home = this.getAttribute('home');
    this.#home.hidden = !home;
    if (home) this.#home.setAttribute('href', home);
    this.#home.replaceChildren(make('span', { 'aria-hidden': 'true' }, '◂'), ` ${this.getAttribute('home-label') || 'All games'}`);
  }

  /** Asks auth/me again (after a sign-in the page made itself, say). */
  async refresh() {
    if (this.getAttribute('accounts') === 'off') return;
    try {
      const r = await fetch(`${this.auth}/me`, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      const me = await r.json();
      this.#ssoEnabled = me.ssoEnabled !== false;
      this.account = me.user ? { name: chipLabel(me.user), guest: Boolean(me.user.is_guest || me.user.isGuest) } : this.#ssoEnabled ? null : undefined;
    } catch {
      this.account = undefined; // no answer: no chip rather than a wrong one
    }
  }

  get account() {
    return this.#account;
  }

  /** undefined: no chip; null: a "Sign in" chip; { name, guest }: the account's chip. */
  set account(value) {
    this.#account = value;
    this.#close();
    this.#acct.replaceChildren();
    this.#chip = null;
    if (value === undefined || this.getAttribute('accounts') === 'off') return;
    if (value === null) {
      this.#chip = make('button', { type: 'button', class: 'chip', part: 'chip', 'aria-label': 'Sign in with Waypoint' }, 'Sign in');
      this.#chip.addEventListener('click', () => this.#act('signin'));
    } else {
      const name = value.guest ? 'Guest' : String(value.name ?? 'Account');
      this.#chip = make('button', { type: 'button', class: 'chip', part: 'chip', 'aria-label': `Account: ${name}`, 'aria-haspopup': 'menu', 'aria-expanded': 'false' });
      this.#chip.append(make('span', { class: 'name' }, name), make('span', { class: 'caret', 'aria-hidden': 'true' }, '▾'));
      this.#chip.addEventListener('click', () => (this.#open ? this.#close() : this.#openMenu()));
    }
    this.#acct.append(this.#chip);
  }

  #items() {
    return [...(this.#menu?.querySelectorAll('[role="menuitem"]') ?? [])];
  }

  #openMenu() {
    this.#open = true;
    this.#menu = make('div', { class: 'menu', part: 'menu', role: 'menu', id: 'menu', 'aria-label': 'Account menu' });
    for (const [what, label] of ITEMS) {
      // no Waypoint: nothing to switch or to end there
      if (what !== 'signout' && (!this.#ssoEnabled || this.getAttribute('sso') === 'off')) continue;
      const b = make('button', { type: 'button', role: 'menuitem', tabindex: '-1' }, label);
      b.addEventListener('click', () => {
        this.#close();
        this.#act(what);
      });
      this.#menu.append(b);
    }
    this.#acct.append(this.#menu);
    this.#chip.setAttribute('aria-expanded', 'true');
    this.#chip.setAttribute('aria-controls', 'menu');
    this.#items()[0]?.focus();
    document.addEventListener('pointerdown', this.#away);
  }

  #close(refocus) {
    if (!this.#open) return;
    this.#open = false;
    this.#menu?.remove();
    this.#menu = null;
    this.#chip?.setAttribute('aria-expanded', 'false');
    this.#chip?.removeAttribute('aria-controls');
    document.removeEventListener('pointerdown', this.#away);
    if (refocus) this.#chip?.focus();
  }

  #onKey(e) {
    if (!this.#open) {
      if (e.key === 'ArrowDown' && this.#chip?.hasAttribute('aria-haspopup') && this.#root.activeElement === this.#chip) {
        e.preventDefault();
        this.#openMenu();
      }
      return;
    }
    const list = this.#items();
    const at = list.indexOf(this.#root.activeElement);
    if (e.key === 'Escape') {
      e.preventDefault();
      this.#close(true);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      list[(at + 1) % list.length]?.focus();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      list[(at - 1 + list.length) % list.length]?.focus();
    } else if (e.key === 'Home') {
      e.preventDefault();
      list[0]?.focus();
    } else if (e.key === 'End') {
      e.preventDefault();
      list[list.length - 1]?.focus();
    } else if (e.key === 'Tab') this.#close();
  }

  /** Fires fleet-topbar-<what>; unless the app took it over, does the usual. */
  async #act(what) {
    const event = new CustomEvent(`fleet-topbar-${what}`, { bubbles: true, composed: true, cancelable: true, detail: { account: this.#account } });
    if (!this.dispatchEvent(event)) return;
    const back = `${location.pathname}${location.search}`;
    if (what === 'signin') return location.assign(signInUrl(this.auth, { next: back }));
    if (what === 'switch') return location.assign(signInUrl(this.auth, { next: back, prompt: 'login' }));
    try {
      const r = await fetch(`${this.auth}/logout`, { method: 'POST', credentials: 'same-origin' });
      if (!r.ok) throw new Error();
    } catch {
      window.alert('Could not sign out. Try again.');
      return;
    }
    if (what === 'signout') return location.reload();
    const home = this.getAttribute('home');
    location.assign(`${this.auth}/logout-all${home ? `?return_to=${encodeURIComponent(home)}` : ''}`);
  }
}

/** The app's sign-in route: next (a page here to come back to), prompt 'login' to switch. */
export function signInUrl(auth = '/api/auth', { next, prompt } = {}) {
  const params = new URLSearchParams();
  if (next && next !== '/') params.set('next', next);
  if (prompt === 'login') params.set('prompt', 'login');
  const qs = params.toString();
  return `${auth.replace(/\/+$/, '')}/sso/login${qs ? `?${qs}` : ''}`;
}

/** Every bar on the page asks auth/me again. */
export function refreshTopbars() {
  for (const el of document.querySelectorAll('fleet-topbar')) el.refresh?.();
}

if (typeof customElements !== 'undefined' && !customElements.get('fleet-topbar')) customElements.define('fleet-topbar', FleetTopbar);
