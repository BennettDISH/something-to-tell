# fleet-kit

What every small Express app that signs in with Waypoint used to copy, in one versioned package:
sign-in, the cookie session, the admin gate, health, security headers, the same-origin write
guard, rate limits, the request log, error handling, R2, migrations, the guest sweep, WebSocket
limits, the games top bar, and the test fakes. Each piece is the best copy from the apps it came
from, made installable, so the next change (PKCE, say) is one release and a version bump per
app instead of a hand edit in every repo.

It holds no secrets: only code. Every setting comes from the app's environment.

## Install

Vendored, with the tarball committed in the app (`npm run pack:vendor` here, then copy it from
`vendor-out/`). The repo is private and a deploy build has no token, so this is how every app has it:

```json
"fleet-kit": "file:vendor/fleet-kit-1.0.8.tgz"
```

From a tag, if the repo is ever public:

```json
"fleet-kit": "github:<owner>/fleet-kit#v1.0.8"
```

A change is always a new version, never a tarball packed again under the old one: the lockfile
pins the tarball's integrity, and npm will not take a different file for the same version.

Node 22. Express 4 or 5. ESM apps import `fleet-kit/server`; CommonJS apps `require('fleet-kit/server')`
(a bundled build in `dist/cjs`). R2 is its own entry, `fleet-kit/server/r2`, because it needs
`@aws-sdk/client-s3` in the app.

## The whole sign-in surface

```js
import path from 'node:path';
import express from 'express';
import {
  createWaypoint, trustOneProxy, requestLog, securityHeaders, sameOriginWrites,
  health, apiNotFound, spaFallback, errorHandler, migrate,
} from 'fleet-kit/server';

const app = trustOneProxy(express());          // trust proxy 1: req.ip is the visitor, not what they wrote
app.use(requestLog());                          // id per request, no query strings, tokens as :token
app.use(securityHeaders({ widgetOrigin: process.env.WIDGET_ORIGIN }));

const wp = createWaypoint({
  app: 'sf',                                    // cookie names: __Host-sf_session, __Host-sf_oauth_state, _oauth_next
  appName: 'Spellforge',
  guests: 'allow',                              // or 'refuse': a Waypoint guest gets a 403 before any row is saved
  onSignIn: async (u, { how }) => upsertUser(u),// u: { central_user_id, username, email, first_name, last_name, is_guest }
  session: {
    load: async (claims) => findUser(claims.sub),            // the row, with token_version; null = signed out
    onSignOut: async (claims) => bumpTokenVersion(claims.sub, claims.tv),
    onRenew: async (user) => stampLastSeen(user.id),
  },
});

app.get('/health', health({ db: pool }));       // SELECT 1 against 2 s; 503 with no database words
app.use('/api', sameOriginWrites());            // a write from another site's page is refused (wp.router has its own)
app.use('/api', express.json());
app.use('/api/auth', wp.router);                // config, sso/login, sso/callback, me, logout, logout-all, guest
app.use(wp.session.loadUser);                   // req.user from the cookie (null when signed out)
app.use('/api/admin', wp.requireAdmin, adminRoutes);
app.use(wp.adminPage({ pages: /^\/admin(?:\/.*)?$/ }));   // signed out → sign in and back; others → 403; any spelling of the path
app.use('/api', apiNotFound());
app.use(express.static('dist'));
app.use(spaFallback(path.resolve('dist/index.html')));
app.use(errorHandler());

await migrate({ db: pool, dir: 'migrations' }); // a failed step stops the boot
```

Two hooks for an app's own rules: `publicUser(user, req)` shapes the account that /me and the
sign-in answers send (it may be async, for an answer that needs the database), and
`isAdmin(user, { listed })` gives the app admins of its own (`listed` is the ADMIN_CENTRAL_USER_IDS
answer, to keep the list and add to it). Either may be async; a guest is never an admin, and a
hook that throws or answers anything but `true` is a no.

`onSignIn` may refuse someone in the app's own words (an allow list, an invite): throw
`httpError(403, 'This account is not allowed to use Drop')` (any 4xx; add `code: 'not_invited'`
to name it). Password sign-in, sign-up and the guest button answer that status and message; the
callback sends the browser to `signInPage?error=<code, or sso_refused>&message=<the message>`.
Nothing is saved, no session is set, and nothing is logged. Show `message` as text, never as HTML.
A no-guest app's refusal page links back to `signInPage?error=sso_guest`.

Sign-out ends a session everywhere only with `load`: the row's `token_version` is what refuses every
other copy, and `onSignOut` is what raises it. Without `load` the token is all there is, so signing
out clears this browser's cookie and a copy of the token works until its exp.

`adminPage`'s `pages` is asked about every spelling of the path, in any case: `/ADMIN`, `/%61dmin`,
`//admin`, `/x/../admin`, `/admin/`. Write the pattern for the plain path; a non-RegExp with
`test(path)` also works. For a gate of an app's own: `const isAdminPath = pathMatcher(/^\/admin(?:\/|$)/)`,
then `isAdminPath(req.path)`. Never read `req.path` by hand to decide who may see something.

`password: true` brings sign-up with it; `register: false` keeps sign-in and takes sign-up away.
Don't close a kit route with a route of your own in front of the mount: `/api/auth//register` gets past it.

A hand call to the kit's middleware gets any failure as `next(err)`, so a `next` of its own has to
look at its argument: `wp.requireAdmin(req, res, (err) => (err ? next(err) : go()))`.

### Sessions are tied to their app

Every token says which app it is for (`aud`, the app code in `createWaypoint({ app })`), and an app
refuses another's, under its own cookie or through a `legacy` reader. So the app code has to be
unique across apps that could share a secret. A token from before 1.0.7 names no app: it counts
if it was minted before 2026-12-01, until its own exp, and `/me` swaps it for one that names the
app, so nobody is signed out by the bump. **Deploy every app on 1.0.7 before that date**; one that
deploys later signs out the sessions it minted after it. The last such token is gone one TTL after
that date, whichever app's sessions last longest, and that branch of the check can go then.

A test that signs a kit token by hand needs `aud: '<app code>'`, or it fails from that date.
`wp.session.mint(user)` adds it.

Env names are the kit's and match what the apps already use: `AUTH_SERVICE_URL`, `SSO_CLIENT_ID`,
`SSO_CLIENT_SECRET`, `APP_BASE_URL` (optional), `SESSION_SECRET` (or `JWT_SECRET`),
`ADMIN_CENTRAL_USER_IDS`, `GUEST_RETENTION_DAYS`, `GUEST_CLEANUP_ENABLED`, and the `R2_*` set. An app
whose names differ maps them at adoption (`env: { ...process.env, APP_BASE_URL: process.env.GAME_BASE_URL }`).

### What each piece does

| Module | Does | Came from |
|---|---|---|
| `server/waypoint` | authorize URL built on the server; state and return-to in `__Host-` cookies (10 min); `safeNext`; `prompt=login` (Switch account); code exchanged server to server with `redirect_uri`; guest refusal; one-click guest with a per-address cap; optional password sign-in, register and claim; `/me`; `/logout`; `/logout-all` (Waypoint's own sign-out); 10 s time limit on every call; per-address limits on everything that calls Waypoint | Spellforge's auth routes, the bug tracker's guest refusal, Tilerealm's no-database variant |
| `server/session` | `__Host-<app>_session`, httpOnly, Secure, SameSite=Lax; HS256 token (verifies jsonwebtoken's) naming its app (`aud`); `token_version` (with `load`, sign-out ends it everywhere); slides once a day on `/me`; legacy readers to move an app over without signing anyone out | Spellforge's session, Quickplay's row re-read |
| `server/admin` | `ADMIN_CENTRAL_USER_IDS` read on every check, fails closed, never a guest; the `/admin` page gate, whichever way the path is spelled; `requireAdmin` | the family app's admin pages |
| `server/paths` | `pathMatcher`, `pathSpellings`: a path in any case and every spelling, for any gate | the /admin fixes across the fleet |
| `server/push` | `isPushEndpoint` (real push services, plain addresses only), `validPushKeys` | Keep Close, the family app |
| `server/health` | `SELECT 1` raced against 2 s, `no-store`, `db: 'off'` without a database | Tilerealm's health |
| `server/headers` | CSP (widget and Waypoint origins where they belong; `nonce: true` for a fresh nonce per response in `res.locals.cspNonce` and script-src), HSTS, frame protection, nosniff, Referrer-Policy, COOP, no X-Powered-By, without helmet; `noStore()` | Tenant Interviews' headers, Keep Close's no-helmet block |
| `server/sameOrigin` | `Sec-Fetch-Site` write guard; `originAllowed` for socket upgrades | Spellforge, Tilerealm |
| `server/limits` | sliding window per visitor (IPv6 by /64), 429 with Retry-After, `budget`, `trustOneProxy`, `assertTrustProxy` | Tenant Interviews, Spellforge, Quickplay |
| `server/log` | the fleet's request log (segments of 16+ characters hidden as `:token`; `tokens: ['/p/:token']` for an app's shorter share links); `logError` | the patterns audit |
| `server/errors` | JSON 404 under /api, asset 404, SPA fallback with `no-store`, the last handler (4xx says what, a 4xx marked `expose: false` keeps its status with the standard phrase, 5xx never), `HttpError`, Postgres bad-request codes | Spellforge, Tenant Interviews, Stock Market |
| `server/r2` | store with 15 s limits, private or public caching, list, head, copy (cached like a put), deletePrefix, `sendObject` (destroyed when the browser leaves), magic-byte sniffing, `moveToR2` for old rows | Inner Circle, Meal Planner, the family app, Tenant Interviews, the bug tracker |
| `server/migrate` | numbered SQL under an advisory lock; SQLite steps by `user_version` | Quickplay, the family app |
| `server/guestCheck`, `server/guestSweep` | Waypoint's word on idle guests; one sweep engine fed the app's tables, measured and undone if anything else moves | Tilerealm, Spellforge |
| `ws` | client address as Express reads it, sockets per address, frame budget, bad-frame window, wrong-guess counts, Origin check at the upgrade, heartbeat, frame parsing (TypeScript, built to JS) | Spellweave, Tilerealm |
| `client/topbar` | `<fleet-topbar>`: "◂ All games" and the account chip, safe-area insets, shadow DOM, events an app can take over | Tilerealm's bar, Admiral's safe-area CSS |
| `test/*` | a whole fake Waypoint, a fake R2, a cached PGlite with a pg Pool shape; `test/security`, below | Tilerealm, the family app, Stock Market |

## The top bar

```html
<link rel="stylesheet" href="/fleet-kit/topbar.css">
<script type="module" src="/fleet-kit/topbar.js"></script>
<fleet-topbar home="https://<the games hub>/"></fleet-topbar>
```

A plain-JS app serves the files with `app.use('/fleet-kit', clientAssets())`; a bundled app imports
`fleet-kit/client/topbar` and `fleet-kit/client/topbar.css`. The bar asks `/api/auth/me` itself
(the cookie rides along). Its menu fires `fleet-topbar-signin`, `-switch`, `-signout` and
`-signout-all`; call `preventDefault()` to take one over (a guest's sign-out confirm, say), or
leave them: sign in and come back, sign out and reload, sign out of everything and land on
`home`. `accounts="off"` for a game without accounts; `no-pad` when the page lays itself out
under the bar (`--fleet-topbar-height`). Its CSP needs nothing beyond the default.

## Adoption recipe (one todo per app)

Work in a worktree on a branch, never in the main checkout.

1. **Install.** Add the dependency (tag or vendored tarball), `npm install`, commit the lockfile.
2. **Sign-in.** Replace `config/sso.js` / `config/waypoint.js` and the auth routes with
   `createWaypoint`. Keep the app's own part in `onSignIn` (the users-table upsert) and `load`.
   If Waypoint has the app's callback registered somewhere other than `/api/auth/sso/callback`,
   pass `callbackPath` and mount `wp.callback` there, so nothing changes at Waypoint.
3. **Session.**
   - Cookie apps: add a `legacy` reader for the old cookie (`{ cookie: 'old_name', read }`); it is
     read once, replaced by `__Host-<app>_session` and cleared. Nobody is signed out.
   - Token apps (a bearer token in localStorage): the page stops sending it and stops storing
     it. Either everyone signs in once, or add `{ bearer: true, read }` and have the page send
     its old token once to `/api/auth/me`, then delete it: nobody is signed out.
   - Add `token_version` to the users table (`DEFAULT 0`), with `load` and `onSignOut`, for
     sign-out-everywhere.
4. **The rest.** Swap the copies of health, headers (`securityHeaders` with the widget origin;
   drop helmet), limits, request log (drop morgan), errors, same-origin guard, guest check, R2
   and migrations for the kit's, one at a time with the app's tests running.
5. **Delete** the local copies and the app's own fake Waypoint; use `fleet-kit/test/*`.
6. **Keep** what is the app's: the admin lists, the users-table mapping, the sweep's tables.
7. **Front end** (token apps): `fetch` with the cookie (no Authorization header), the sign-in
   page goes to `/api/auth/sso/login?next=…`, the callback page goes away (the server redirects),
   the top bar becomes `<fleet-topbar>`.
8. **Check.** Tests and build green, then in a browser: the sign-in round trip, a guest,
   Switch account, the admin's 403 for anyone else, the bug widget, and no CSP errors in the
   console. Update the app's CLAUDE.md file map.

## The security test set

Every app runs `fleet-kit/test/security` on its own routes in its normal tests, so a repeat of a known
flaw fails before it can be pushed. It reads the app's route table, so a route nobody decided about
fails too. Import it before the app is built:

```js
import test, { before, after } from 'node:test';
import { securityChecks, pushKeys } from 'fleet-kit/test/security';
import { app, wp } from '../server.js';

let server, base;
before(async () => { server = app.listen(0); await once(server, 'listening'); base = `http://127.0.0.1:${server.address().port}`; });
after(() => { server.closeAllConnections(); server.close(); });
const cookie = (user) => ({ cookie: `__Host-sf_session=${wp.session.mint(user)}` });
const keys = pushKeys();

for (const check of securityChecks({
  app,
  base: () => base,
  as: { user: () => cookie(ann), other: () => cookie(bob), guest: () => cookie(aGuest), admin: () => cookie(theAdmin) },
  public: ['GET /api/health', '* /api/auth/*', 'GET /join/:code'],
  admin: ['/api/admin/*'],
  adminPages: ['/admin'],
  closed: ['POST /api/auth/register'],
  crossSite: { except: ['POST /api/bugs'] },
  noStore: { except: ['GET /api/photos/:id'] },
  owned: { params: { id: () => annsList.id }, except: ['GET /api/invites/:code'] },
  guests: { refused: ['POST /api/uploads'] },
  push: { route: 'POST /api/push/subscribe', body: (endpoint) => ({ endpoint, keys }), count: () => countSubs() },
  headers: { path: '/' },
})) test(check.name, check.run);
```

A walk is thousands of requests, so turn the app's request log off in this file, or set
`console.log = () => {}` after the imports. In a CommonJS test file, `await import()` it inside a
`test()` and run the checks as `t.test` subtests, and require the app after that.

Only the checks you give options for run. Every list fails when an entry matches no route, so it
can't go stale. A check that fails says which route and which spelling. In a test file that starts
its server in a before-hook, `app` and `base` may be getters. For a `server.js` that builds and
listens for itself, set `PORT=0`, import it after this file, and `await appListening()` answers
`{ app, server, base }`; no boot code changes. A check of an app's own that isn't
about routes goes next to these: removal and invite links, say, are the app's own tables.

## Develop

```
npm install
npm test          # builds, then node --test, one file at a time
npm run build     # dist/ws (tsc) and dist/cjs (esbuild); both are committed
npm run pack:vendor   # builds, then vendor-out/fleet-kit-<version>.tgz for vendoring
```

`dist/` is committed so a tag installs without a build step. Bump `version`, add a line to
CHANGELOG.md, build, test, commit, tag.
